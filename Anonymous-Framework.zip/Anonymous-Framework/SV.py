# -*- coding: utf-8 -*-
import os, time
os.system("figlet SaFe-Visit ")
time.sleep(1)
print "[*] —— You Are SaFe Now —— "
os.system("tor &> /dev/null ")
