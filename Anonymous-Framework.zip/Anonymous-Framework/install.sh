function Install() {

apt-get upgrade
apt-get update
apt-get install tor
apt-get install python
apt-get install python2

}

function installReqs() {

pip2 install urllib2
pip2 install urllib
pip2 install request
chmod +x *

}
Install
installReqs
